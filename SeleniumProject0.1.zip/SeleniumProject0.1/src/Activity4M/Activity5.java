package Activity4M;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class Activity5 {

	WebDriver driver = new ChromeDriver();

	@BeforeTest
	public void prerequisite() {
		// declaration and instantiation of objects/variables
		System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir") + "/chromedriver.exe");

		//URL of the selected website
		String baseUrl = "https://demo.guru99.com/test/newtours/index.php";
		driver.get(baseUrl);
	}

	@Test (priority = 1)
	public void RegisterPage(){
		WebElement _linkRegister = driver.findElement(By.xpath("(//a[@href='register.php'])[1] "));
		_linkRegister.click();
	}
	@Test (priority = 2)
	public void Registration(){

		WebElement _textFirstName = driver.findElement(By.name("firstName"));
		_textFirstName.sendKeys("Romel Kent");

		WebElement _textLastName = driver.findElement(By.name("lastName"));
		_textLastName.sendKeys("Avesia");

		WebElement _textPhone = driver.findElement(By.name("phone"));
		_textPhone.sendKeys("9186635958");

		WebElement _textuserName = driver.findElement(By.id("userName"));
		_textuserName.sendKeys("Swiftred18@gmail.com");

		WebElement _textaddress1 = driver.findElement(By.name("address1"));
		_textaddress1.sendKeys("Looc, moller");

		WebElement _textcity = driver.findElement(By.name("city"));
		_textcity.sendKeys("Lapu-lapu");

		WebElement _textstate = driver.findElement(By.name("state"));
		_textstate.sendKeys("Cebu");


		WebElement _textpostalCode = driver.findElement(By.name("postalCode"));
		_textpostalCode.sendKeys("6015");

		Select _dropdowncountry = new Select(driver.findElement(By.name("country")));
		_dropdowncountry.selectByVisibleText("BANGLADESH");

		WebElement _textemail = driver.findElement(By.name("email"));
		_textemail.sendKeys("avesia12345");

		WebElement _textpassword = driver.findElement(By.name("password"));
		_textpassword.sendKeys("avesia#12345");

		WebElement _textconfirmPassword = driver.findElement(By.name("confirmPassword"));
		_textconfirmPassword.sendKeys("avesia#12345");

		WebElement _buttonRegister = driver.findElement(By.name("submit"));
		_buttonRegister.click();
	}
	@Test (priority = 3)
	public void  LoginPage(){
		WebElement _linkLogin = driver.findElement(By.xpath("(//a[@href='login.php'])[1] "));
		_linkLogin.click();
	}
	@Test (priority = 4)
	public void Login(){
		WebElement _textuserName2 = driver.findElement(By.name("userName"));
		_textuserName2.sendKeys("avesia12345");

		WebElement _textpassword2 = driver.findElement(By.name("password"));
		_textpassword2.sendKeys("avesia#12345");

		WebElement _buttonLogin2 = driver.findElement(By.name("submit"));
		_buttonLogin2.click();

	}
	@AfterTest
	public void postrequisite(){
		driver.close();
	}
}
