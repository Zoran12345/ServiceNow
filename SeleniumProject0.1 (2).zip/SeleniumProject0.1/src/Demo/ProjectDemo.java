package Demo;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class ProjectDemo {

	public static void main(String[] args) {
        // declaration and instantiation of objects/variables
    	System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir") + "/chromedriver.exe");
		WebDriver driver = new ChromeDriver();
 
		//URL of the selected website
        String baseUrl = "https://katalon-demo-cura.herokuapp.com/profile.php#login";
 
        // launch Google Chrome and direct it to the Base URL
        driver.get(baseUrl);
 
        //Find the text input element by its name
        WebElement _textBoxUsername = driver.findElement(By.id("txt-username"));
        _textBoxUsername.sendKeys("John Doe");
        
        WebElement _textBoxPassword = driver.findElement(By.name("password"));
        _textBoxPassword.sendKeys("ThisIsNotAPassword");
        
        WebElement _buttonLogin = driver.findElement(By.id("btn-login"));
        _buttonLogin.click();
        
        
//        //Enter search key on the search bar
//        element.sendKeys("Accenture!");
//        //Submit the form to earch the search key you inputted
//        element.submit();
//        //close Google Chrome
//        driver.close();
    }
}
