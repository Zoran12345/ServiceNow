package common;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class BaseTest {

	public static WebDriver driver;
	public void openBrowser() {
		System.setProperty("webdriver.chrome.driver",System.getProperty("user.dir")+ "/bin/chromedriver.exe");
		driver = new ChromeDriver();
	}
	public void openUrl(String url) {
		driver.get("http://www.google.com");
		System.out.println("Opened the url.");
	}
	public void endTest() {
		driver.close();
		System.out.println("Test is finished.");
	}
}
