package pageobjects;

import org.testng.annotations.Test;
import common.BaseTest;
import pageobjects.GooglePage;

@SuppressWarnings("unused")
public class GoogleTest extends BaseTest {

	@Test
	public void GoogleTest_1() throws Exception{
		openBrowser();
		openUrl("http:\\www.google.com");
		GooglePage actions = new GooglePage(driver);
		actions.enterSearchBar("Accenture");
		actions.submitSearch();
		endTest();
	}
}