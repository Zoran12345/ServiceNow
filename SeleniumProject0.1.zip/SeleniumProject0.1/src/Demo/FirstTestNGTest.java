package Demo;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;


public class FirstTestNGTest {

	WebDriver driver = new ChromeDriver();

	@BeforeTest
	public void prerequisite(){
		// declaration and instantiation of objects/variables
		System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir") + "/chromedriver.exe");

		//URL of the selected website
		String baseUrl = "https://katalon-demo-cura.herokuapp.com/profile.php#login";

		// launch Google Chrome and direct it to the Base URL
		driver.get(baseUrl);
	}
	@Test
	public void main(){

		WebElement _textBoxUsername = driver.findElement(By.xpath("(//input[@placeholder='Username'])[2]"));
		_textBoxUsername.sendKeys("John Doe");

		WebElement _textBoxPassword = driver.findElement(By.name("password"));
		_textBoxPassword.sendKeys("ThisIsNotAPassword");

		WebElement _buttonLogin = driver.findElement(By.id("btn-login"));
		_buttonLogin.click();

		Select _dropdownFacility = new Select(driver.findElement(By.id("combo_facility")));
		_dropdownFacility.selectByVisibleText("Seoul CURA Healthcare Center");

	}
	@AfterTest
	public void postrequisite(){
		driver.close();
	}
}

